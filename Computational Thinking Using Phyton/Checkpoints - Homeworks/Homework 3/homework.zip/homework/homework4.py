ladoA = input("Qual o valor do lado A?")
ladoA = int(ladoA)
ladoB = input("Qual o valor do lado B?")
ladoB = int(ladoB)
ladoC = input("Qual o valor do lado C?")
ladoC = int(ladoC)

perimetro = ladoA+ladoB+ladoC

print("O perímetro deste triângulo é de: ", perimetro)
