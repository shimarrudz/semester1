dollar1 = input("Quantos reais voce deseja converter para dólar?")
dollar1 = float(dollar1)

dollar_reais = dollar1*5.11

print(f"O resultado da conversão é de: {dollar_reais: .2f} ")
