anos = input("Quantos anos você tem?")
anos = int(anos)
meses = input("E quantos meses?")
meses = int(meses)
dias = input("E quantos dias")
dias = int(dias)

diastotais = (anos*365)+(meses*30)+dias

print("Você tem em dias de vida: ", diastotais )

