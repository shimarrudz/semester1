kWh1 = input("Digite seu consumo de energia em Kwh")
kWh1 = float(kWh1)

kWh1 = kWh1*0.20

print(f"O consumo de energia em kWh é de: {kWh1:.2f}")
