quilometros = input("Quantos quilometros foram rodados?")
quilometros = int(quilometros)
litros = input("Quantos litros foram abastecidos?")
litros = int(litros)

km_L = quilometros/litros

print("A quantidade de Km/L é de: ", km_L )

